
# Auto Scaling Group (ASG) Module

## 1. Overview

This reusable Terraform module provisions an AWS Auto Scaling Group (ASG) using an existing EC2 Launch Template.

The module manages instance capacity, subnet placement, target group association, health checks, rolling instance refresh, and tag propagation.

It is designed for integration into a reusable AWS infrastructure framework and supports production-oriented configuration through explicit inputs and validation.

## 2. Responsibilities

This module is responsible for:

- Creating an Auto Scaling Group.
- Launching EC2 instances through an existing Launch Template.
- Placing instances in the supplied subnets.
- Associating one or more existing ALB target groups.
- Configuring minimum, maximum, and desired instance capacity.
- Configuring EC2 or ELB health checks.
- Supporting rolling instance refresh.
- Configuring instance refresh health percentages and warmup.
- Requesting automatic rollback when an instance refresh fails.
- Propagating common tags to launched instances.
- Exposing ASG attributes through Terraform outputs.

## 3. Architecture

The intended integration flow is:

```text
Application Load Balancer Module
             |
             v
        Target Group
             |
             | target_group_arns
             v
      Auto Scaling Group
             |
             | launch_template_id
             | launch_template_version
             v
       Launch Template
             |
             v
          EC2 Instances
```

The environment root configuration is responsible for wiring the modules together.

The ASG module does not create a separate Launch Template, ALB, target group, or individually managed EC2 instances.

## 4. Directory Structure

```text
modules/
└── ASG/
    ├── versions.tf
    ├── variables.tf
    ├── locals.tf
    ├── main.tf
    ├── outputs.tf
    └── README.md
```

## 5. Requirements

- Terraform >= 1.9.0 and < 2.0.0.
- AWS provider >= 6.0.0 and < 7.0.0.
- An existing EC2 Launch Template.
- An explicit numeric Launch Template version.
- At least two suitable subnets across the intended Availability Zones.
- Existing target groups when ELB health checks are enabled.
- Appropriate IAM permissions for the Terraform execution identity.
- Sufficient EC2 capacity and account quotas for normal scaling and instance refresh.

The reusable module declares its Terraform and provider requirements but does not configure the AWS provider. Provider configuration and dependency lock-file management belong to the root configuration.

## 6. Resources

| Resource | Purpose |
|---|---|
| `aws_autoscaling_group.this` | Creates and manages the Auto Scaling Group |

The ASG launches and manages EC2 instances using the configured Launch Template.

## 7. Input Variables

| Variable | Type | Default | Description |
|---|---|---|---|
| `name` | `string` | Required | Base name used to generate the ASG name |
| `launch_template_id` | `string` | Required | ID of the existing Launch Template |
| `launch_template_version` | `string` | Required | Explicit numeric Launch Template version |
| `subnet_ids` | `set(string)` | Required | Subnets where instances can launch |
| `target_group_arns` | `set(string)` | `[]` | Existing target group ARNs associated with the ASG |
| `min_size` | `number` | `2` | Minimum instance capacity |
| `max_size` | `number` | `6` | Maximum instance capacity |
| `desired_capacity` | `number` | `2` | Desired instance capacity |
| `health_check_type` | `string` | `"ELB"` | Health-check mechanism: `EC2` or `ELB` |
| `health_check_grace_period` | `number` | `300` | Seconds to wait after launch before acting on failed health checks |
| `protect_from_scale_in` | `bool` | `false` | Enables protection against scale-in termination |
| `termination_policies` | `list(string)` | `["Default"]` | Ordered list of termination policies |
| `enable_instance_refresh` | `bool` | `true` | Enables rolling instance refresh configuration |
| `instance_refresh_min_healthy_percentage` | `number` | `100` | Minimum healthy percentage during refresh |
| `instance_refresh_max_healthy_percentage` | `number` | `200` | Maximum healthy percentage permitted during refresh |
| `instance_refresh_warmup_seconds` | `number` | `300` | Instance warmup duration during refresh |
| `common_tags` | `map(string)` | `{}` | Additional tags applied to the ASG and propagated to launched instances |

Refer to `variables.tf` for the authoritative input types, defaults, and validation rules.

## 8. Input Validation

The module validates:

- ASG naming format and length.
- Launch Template ID format.
- Positive numeric Launch Template version.
- Subnet ID formats and a minimum of two subnet IDs.
- Target group ARN formats when provided.
- Non-negative integer minimum and desired capacity.
- Positive integer maximum capacity.
- The supported health-check types.
- Non-negative integer health-check grace period.
- Non-empty termination policy lists.
- Integer instance refresh percentages within their supported input ranges.
- Non-negative integer instance refresh warmup.

Resource lifecycle preconditions additionally check:

```text
min_size <= desired_capacity <= max_size
```

When instance refresh is enabled, the configured healthy percentages must satisfy:

```text
min_healthy_percentage <= max_healthy_percentage
```

The difference between the maximum and minimum healthy percentages must not exceed 100 percentage points.

When `health_check_type` is `ELB`, at least one target group ARN must be provided.

Input-format validation does not establish that AWS resources exist, that subnets belong to the correct VPC, or that target groups and instances can communicate.

## 9. Capacity Management

The default capacity configuration is:

| Setting | Default |
|---|---:|
| Minimum capacity | 2 |
| Desired capacity | 2 |
| Maximum capacity | 6 |

These values are defaults, not universal production sizing recommendations.

Actual capacity must be determined from application demand, availability objectives, scaling behavior, instance type, and cost constraints.

The ASG maintains its configured capacity within the permitted minimum and maximum limits, subject to AWS service behavior and available capacity.

## 10. Launch Template Version Management

The ASG requires an explicit numeric Launch Template version.

For example:

```hcl
launch_template_version = "3"
```

The selected version determines the Launch Template configuration used when the ASG launches instances.

When the Launch Template is updated, the root configuration must pass the intended version to the ASG module. A change to that version can trigger an ASG configuration update and, with instance refresh enabled, a rolling replacement of instances.

A version change does not by itself guarantee that every existing instance is replaced successfully. The actual rollout depends on the instance refresh configuration, health checks, available capacity, and AWS behavior.

Explicit numeric versions make deployment changes easier to review and reproduce than relying on `$Latest`.

## 11. ALB Target Group Integration

The ASG accepts target group ARNs through `target_group_arns`.

The intended integration is:

1. The ALB module creates the target group.
2. The environment root obtains the target group ARN from the ALB module output.
3. The root passes the ARN to the ASG module.
4. AWS associates the target group with the ASG.
5. AWS manages instance registration and deregistration as instances launch and terminate.

The ASG does not create or manage the target group's health-check configuration. That configuration belongs to the ALB module.

When ELB health checks are configured, the application must start successfully and respond to the target group's health checks. The security groups must permit traffic from the ALB to the application instances on the configured application port.

## 12. Health Checks

The module supports:

- `EC2`: Uses EC2 instance health information.
- `ELB`: Uses Elastic Load Balancing health information for associated target groups.

The default health-check grace period is 300 seconds.

The grace period should account for operating system startup, application initialization, dependency connectivity, and the time needed for the application to become healthy.

A grace period that is too short can cause premature replacement. A grace period that is too long can delay recovery from a genuinely failed startup.

The grace period does not replace correct target-group health-check configuration.

## 13. Instance Refresh

When enabled, the ASG configures a rolling instance refresh strategy.

The default settings are:

| Setting | Default |
|---|---:|
| Minimum healthy percentage | 100 |
| Maximum healthy percentage | 200 |
| Instance warmup | 300 seconds |
| Skip matching instances | Enabled |
| Automatic rollback | Requested |

The minimum healthy percentage controls the healthy capacity AWS attempts to retain during refresh.

The maximum healthy percentage controls the permitted capacity above the desired capacity during refresh.

For example, with a desired capacity of two instances and a maximum healthy percentage of 200, the refresh configuration can permit additional temporary instances, subject to AWS capacity calculations and service constraints.

Additional instances can increase temporary infrastructure costs and require sufficient EC2 quota and capacity.

The warmup period gives newly launched instances time to initialize. It should be appropriate for the application's startup and readiness behavior.

Automatic rollback is configured for failed refreshes. It is not a guarantee that every deployment failure will be recovered without intervention.

Before a production rollout, verify:

- Target group health checks.
- Application startup and readiness behavior.
- Instance warmup duration.
- Available EC2 capacity.
- Account quotas.
- Refresh percentage settings.
- Application availability requirements.

## 14. Tagging

The module merges caller-provided tags with standard tags.

Standard tags include:

| Tag | Value |
|---|---|
| `ManagedBy` | `Terraform` |
| `Name` | Generated ASG name |
| `Tier` | `compute` |

The standard tags take precedence when the caller supplies conflicting keys.

The ASG propagates these tags to instances launched by the group.

Tag propagation does not automatically tag every related resource, such as independently managed EBS volumes or load balancer resources. Those resources must be tagged through their respective configurations.

## 15. Security Considerations

- Prefer private application subnets for instances behind an internet-facing ALB.
- Restrict application ingress to the ALB security group.
- Use an appropriately secured Launch Template.
- Apply least-privilege permissions to the EC2 instance profile.
- Require IMDSv2 through the Launch Template configuration.
- Use encrypted EBS volumes through the Launch Template.
- Review instance scale-in protection and termination policies against application behavior.
- Review the impact of desired-capacity changes before applying Terraform.
- Ensure that the ASG has sufficient capacity and quotas for rolling replacements.
- Review changes to Launch Template versions before initiating production refreshes.

The ASG module does not independently enforce all of these controls. They must be configured and verified through the relevant infrastructure modules and AWS account policies.

## 16. Outputs

| Output | Description |
|---|---|
| `autoscaling_group_id` | ASG resource ID |
| `autoscaling_group_arn` | ASG ARN |
| `autoscaling_group_name` | ASG name |
| `min_size` | Configured minimum capacity |
| `max_size` | Configured maximum capacity |
| `desired_capacity` | Configured desired capacity |
| `availability_zones` | Availability Zones used by the ASG |
| `target_group_arns` | Target group ARNs associated with the ASG |
| `launch_template_id` | Launch Template ID used by the ASG |
| `launch_template_version` | Configured numeric Launch Template version |

Refer to `outputs.tf` for the authoritative output definitions.

## 17. Operational Considerations

The ASG manages instance capacity, but this module does not create workload-based scaling policies or CloudWatch alarms.

For production workloads, consider separately configuring:

- Target tracking or step scaling policies.
- CloudWatch alarms.
- Scaling cooldown and warmup behavior.
- Instance refresh monitoring and failure response.
- Application-level availability monitoring.
- Cost and capacity monitoring.

These concerns should be integrated through dedicated modules or root configuration rather than silently added to this module.

## 18. Validation and Deployment

Formatting can be checked with:

```bash
terraform fmt -recursive modules/ASG
terraform fmt -check -recursive modules/ASG
```

These commands verify formatting only.

Provider-backed validation must be performed through a Terraform root configuration that references the module and has completed initialization.

For example, after the module is integrated into the planned environment root:

```bash
terraform -chdir=environments/dev validate
```

Validation does not prove that the configuration will succeed in AWS or that the application will remain available during a rollout.

Before applying changes:

1. Review the Terraform plan.
2. Confirm the Launch Template version.
3. Confirm the ASG capacity values.
4. Verify target group and subnet integration.
5. Review instance refresh behavior and potential temporary capacity increases.
6. Verify AWS quotas, permissions, and regional resource availability.
7. Confirm the deployment and rollback approach.

Do not apply the module until its provider-backed validation and integration review are complete.
